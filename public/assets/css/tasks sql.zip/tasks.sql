-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2024 at 10:53 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `task_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `due_date` date NOT NULL,
  `related_to` varchar(20) NOT NULL,
  `related_id` int(11) NOT NULL,
  `priority` int(11) NOT NULL,
  `assignees` int(11) NOT NULL,
  `followers` int(11) NOT NULL,
  `task_description` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`task_id`, `name`, `status`, `start_date`, `due_date`, `related_to`, `related_id`, `priority`, `assignees`, `followers`, `task_description`, `created_by`) VALUES
(0, 'Shoe', 1, '2024-04-27', '2024-04-28', 'project', 2, 2, 3, 1, 'demo task', 1),
(2, 'Follow the lead', 0, '2024-01-06', '2024-01-11', 'lead', 4, 1, 1, 2, 'Follow the lead', 1),
(3, 'QBS Support', 3, '2024-01-06', '2024-01-24', 'project', 3, 0, 2, 3, 'test', 1),
(4, 'Domain C', 1, '2024-01-07', '2024-01-13', 'ticket', 10, 2, 2, 3, 'test two', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`task_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
